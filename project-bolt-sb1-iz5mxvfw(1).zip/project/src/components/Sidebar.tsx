import React from 'react';
import { MessageSquare, Settings, ChevronLeft, Upload } from 'lucide-react';

interface SidebarProps {
  activeView: string;
  setActiveView: (view: string) => void;
  collapsed: boolean;
  setCollapsed: (collapsed: boolean) => void;
}

export function Sidebar({ activeView, setActiveView, collapsed, setCollapsed }: SidebarProps) {
  const menuItems = [
    {
      id: 'upload',
      icon: Upload,
      title: 'Subir Documentos',
      subtitle: 'Cargar y gestionar archivos'
    },
    {
      id: 'chat',
      icon: MessageSquare,
      title: 'Chat',
      subtitle: 'Conversaciones y mensajes'
    },
    {
      id: 'settings',
      icon: Settings,
      title: 'Configuraciones',
      subtitle: 'Ajustes y preferencias'
    }
  ];

  return (
    <div className={`bg-slate-800 text-white transition-all duration-300 ease-in-out flex flex-col ${
      collapsed ? 'w-16' : 'w-64'
    }`}>
      {/* Header */}
      <div className="p-4 border-b border-slate-700 flex items-center justify-between">
        {!collapsed && (
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 bg-emerald-500 rounded-lg flex items-center justify-center">
              <span className="text-white font-bold">A</span>
            </div>
            <span className="text-xl font-semibold">AppMaster</span>
          </div>
        )}
        <button
          onClick={() => setCollapsed(!collapsed)}
          className="p-2 hover:bg-slate-700 rounded-lg transition-colors"
        >
          <ChevronLeft className={`w-5 h-5 transition-transform ${collapsed ? 'rotate-180' : ''}`} />
        </button>
      </div>

      {/* Menu Items */}
      <div className="flex-1 p-4 space-y-2">
        {menuItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeView === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => setActiveView(item.id)}
              className={`w-full flex items-center space-x-3 p-3 rounded-lg transition-colors ${
                isActive 
                  ? 'bg-slate-700 border-l-4 border-emerald-500' 
                  : 'hover:bg-slate-700'
              }`}
            >
              <Icon className="w-5 h-5 flex-shrink-0" />
              {!collapsed && (
                <div className="text-left">
                  <div className="font-medium">{item.title}</div>
                  <div className="text-sm text-slate-400">{item.subtitle}</div>
                </div>
              )}
            </button>
          );
        })}
      </div>
    </div>
  );
}