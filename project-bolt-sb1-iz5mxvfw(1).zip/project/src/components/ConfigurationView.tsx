import React, { useState } from 'react';
import { Save } from 'lucide-react';

export function ConfigurationView() {
  const [chatWebhook, setChatWebhook] = useState('https://tu-servidor.com/webhook/chat');
  const [docWebhook, setDocWebhook] = useState('https://tu-servidor.com/webhook/documentos');

  const handleSave = (e: React.FormEvent) => {
    e.preventDefault();
    // Aquí iría la lógica para guardar la configuración
    alert('Configuración guardada exitosamente');
  };

  return (
    <div className="h-full bg-white">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-gray-900">Configuraciones</h1>
        <p className="text-gray-600">Personaliza tu experiencia</p>
      </div>

      <div className="p-6">
        <form onSubmit={handleSave} className="max-w-2xl">
          <div className="bg-gray-50 rounded-lg p-6">
            <h2 className="text-lg font-semibold text-gray-900 mb-4">Configuración de Webhooks</h2>
            
            <div className="space-y-6">
              <div>
                <label htmlFor="chatWebhook" className="block text-sm font-medium text-gray-700 mb-2">
                  Webhook para Chat
                </label>
                <input
                  type="url"
                  id="chatWebhook"
                  value={chatWebhook}
                  onChange={(e) => setChatWebhook(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="https://tu-servidor.com/webhook/chat"
                />
                <p className="text-sm text-gray-500 mt-2">
                  URL donde se enviarán los mensajes del chat
                </p>
              </div>

              <div>
                <label htmlFor="docWebhook" className="block text-sm font-medium text-gray-700 mb-2">
                  Webhook para Documentos
                </label>
                <input
                  type="url"
                  id="docWebhook"
                  value={docWebhook}
                  onChange={(e) => setDocWebhook(e.target.value)}
                  className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-emerald-500 focus:border-emerald-500"
                  placeholder="https://tu-servidor.com/webhook/documentos"
                />
                <p className="text-sm text-gray-500 mt-2">
                  URL donde se procesarán los documentos subidos
                </p>
              </div>
            </div>

            <div className="mt-8 flex justify-end">
              <button
                type="submit"
                className="px-6 py-3 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors flex items-center space-x-2"
              >
                <Save className="w-4 h-4" />
                <span>Guardar Configuración</span>
              </button>
            </div>
          </div>
        </form>
      </div>
    </div>
  );
}