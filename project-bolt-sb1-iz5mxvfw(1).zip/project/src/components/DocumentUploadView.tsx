import React, { useState } from 'react';
import { Upload, FileText, Trash2, Download, Plus } from 'lucide-react';

interface Document {
  id: string;
  name: string;
  size: string;
  type: string;
  uploadDate: Date;
}

export function DocumentUploadView() {
  const [documents, setDocuments] = useState<Document[]>([
    {
      id: '1',
      name: 'Manual_Usuario.pdf',
      size: '2.5 MB',
      type: 'PDF',
      uploadDate: new Date('2024-01-15')
    },
    {
      id: '2',
      name: 'Documento_Proyecto.docx',
      size: '1.8 MB',
      type: 'DOCX',
      uploadDate: new Date('2024-01-14')
    }
  ]);

  const handleFileUpload = (event: React.ChangeEvent<HTMLInputElement>) => {
    const files = event.target.files;
    if (!files) return;

    Array.from(files).forEach((file) => {
      const newDocument: Document = {
        id: Date.now().toString(),
        name: file.name,
        size: `${(file.size / 1024 / 1024).toFixed(1)} MB`,
        type: file.name.split('.').pop()?.toUpperCase() || 'FILE',
        uploadDate: new Date()
      };
      setDocuments(prev => [...prev, newDocument]);
    });

    event.target.value = '';
  };

  const handleDeleteDocument = (id: string) => {
    setDocuments(prev => prev.filter(doc => doc.id !== id));
  };

  return (
    <div className="h-full bg-white">
      <div className="p-6 border-b border-gray-200">
        <h1 className="text-2xl font-bold text-gray-900">Subir Documentos</h1>
        <p className="text-gray-600">Carga y gestiona tus archivos de forma segura</p>
      </div>

      <div className="p-6">
        {/* Upload Area */}
        <div className="bg-gray-50 rounded-xl p-8 border-2 border-dashed border-gray-300 text-center hover:border-emerald-500 transition-colors mb-8">
          <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
          <p className="text-lg font-medium text-gray-700 mb-2">Arrastra archivos aquí o haz clic para seleccionar</p>
          <p className="text-gray-500 mb-6">Soporta PDF, DOC, DOCX, TXT hasta 10MB</p>
          <label className="cursor-pointer">
            <input
              type="file"
              multiple
              accept=".pdf,.doc,.docx,.txt"
              onChange={handleFileUpload}
              className="hidden"
            />
            <span className="inline-flex items-center space-x-2 px-6 py-3 bg-emerald-500 text-white rounded-lg hover:bg-emerald-600 transition-colors">
              <Plus className="w-4 h-4" />
              <span>Seleccionar Archivos</span>
            </span>
          </label>
        </div>

        {/* Documents Section */}
        <div className="bg-white rounded-lg border border-gray-200 p-6">
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-lg font-semibold text-gray-900">Documentos Recientes</h2>
            <span className="text-sm text-gray-500">{documents.length} documento(s)</span>
          </div>

          {documents.length === 0 ? (
            <div className="text-center py-12">
              <FileText className="w-12 h-12 text-gray-300 mx-auto mb-4" />
              <p className="text-gray-500">No hay documentos subidos</p>
              <p className="text-sm text-gray-400">Sube tu primer documento para comenzar</p>
            </div>
          ) : (
            <div className="space-y-3">
              {documents.map((doc) => (
                <div key={doc.id} className="flex items-center justify-between p-4 border border-gray-200 rounded-lg hover:shadow-md transition-shadow">
                  <div className="flex items-center space-x-4">
                    <div className="w-12 h-12 bg-blue-100 rounded-lg flex items-center justify-center">
                      <FileText className="w-6 h-6 text-blue-600" />
                    </div>
                    <div>
                      <h3 className="font-medium text-gray-900">{doc.name}</h3>
                      <p className="text-sm text-gray-500">{doc.size} • {doc.type} • {doc.uploadDate.toLocaleDateString('es-ES')}</p>
                    </div>
                  </div>
                  
                  <div className="flex items-center space-x-2">
                    <button 
                      className="p-2 text-gray-400 hover:text-blue-600 hover:bg-blue-50 rounded-lg transition-colors"
                      title="Descargar"
                    >
                      <Download className="w-4 h-4" />
                    </button>
                    <button 
                      onClick={() => handleDeleteDocument(doc.id)}
                      className="p-2 text-gray-400 hover:text-red-600 hover:bg-red-50 rounded-lg transition-colors"
                      title="Eliminar"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}