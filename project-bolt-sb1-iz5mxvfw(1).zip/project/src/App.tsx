import React, { useState } from 'react';
import { Sidebar } from './components/Sidebar';
import { Chat } from './components/Chat';
import { DocumentPanel } from './components/DocumentPanel';

function App() {
  const [activeView, setActiveView] = useState('chat');
  const [leftPanelCollapsed, setLeftPanelCollapsed] = useState(false);
  const [rightPanelCollapsed, setRightPanelCollapsed] = useState(false);

  return (
    <div className="min-h-screen bg-gray-100 flex">
      <Sidebar
        activeView={activeView}
        setActiveView={setActiveView}
        collapsed={leftPanelCollapsed}
        setCollapsed={setLeftPanelCollapsed}
      />
      
      <Chat
        leftCollapsed={leftPanelCollapsed}
        rightCollapsed={rightPanelCollapsed}
        activeView={activeView}
      />
      
      <DocumentPanel
        collapsed={rightPanelCollapsed}
        setCollapsed={setRightPanelCollapsed}
      />
    </div>
  );
}

export default App;